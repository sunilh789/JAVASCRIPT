var emp={
	
              name:"sunilpatel"	,
			  age:25,
			  salary:2000,
			  address:{
				          city:"Bengaluru",
				          state:"Karnataka",
						  pincode:560100
			          }
	 
         };
		 
		 console.log("Employee Name: "+emp.name);
		 console.log("Employee Age: "+emp.age);
		 console.log("Employee Salary: "+emp.salary);
		 console.log("****Employee Address****");
		 console.log("City: "+emp.address.city);
		 console.log("State: "+emp.address.state);
		 console.log("Pincode: "+emp.address.pincode);
		 
		 