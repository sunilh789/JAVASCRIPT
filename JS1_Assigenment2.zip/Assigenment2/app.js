var pd={
	
              name:"sunilpatel"	,
              age:25,
              dob:"11-09-1991",
              pob:"bengaluru"
			
	 
         };
		 
		 console.log("Name: "+pd.name);
		 console.log("Age: "+pd.age);
		 console.log("Date Of Birth : "+pd.dob);
		 console.log("Place of Birth "+pd.pob);
		 
		 