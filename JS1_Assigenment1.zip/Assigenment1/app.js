var name="sunil patel";
var age=25;
var dob="11-11-1991";
var pob="Bengaluru"

console.log(name);
console.log(age);
console.log(dob);
console.log(pob);